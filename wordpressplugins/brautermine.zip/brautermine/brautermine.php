<?php
/**
 * Plugin Name:       Brautermine
 * Description:       Gemeinsame Brautermine planen: Termine im Backend anlegen, Mitglieder tragen sich im Mitgliederbereich als Helfer ein – optional mit Uhrzeit. Shortcode: [brautermine]
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Brauverein Schwabach e.V.
 * License:           GPL-2.0-or-later
 * Text Domain:       brautermine
 */

defined( 'ABSPATH' ) || exit;

final class Brautermine {

	const CPT        = 'brautermin';
	const DB_VERSION = '1';

	private static $css_printed = false;

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'brautermin_helfer';
	}

	/* ------------------------------------------------------------------
	 * Setup
	 * ------------------------------------------------------------------ */

	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_upgrade' ) );
		add_action( 'init', array( __CLASS__, 'register_cpt' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post_' . self::CPT, array( __CLASS__, 'save_meta' ), 10, 2 );
		add_action( 'before_delete_post', array( __CLASS__, 'delete_signups' ) );

		add_filter( 'manage_' . self::CPT . '_posts_columns', array( __CLASS__, 'admin_columns' ) );
		add_action( 'manage_' . self::CPT . '_posts_custom_column', array( __CLASS__, 'admin_column_content' ), 10, 2 );
		add_filter( 'manage_edit-' . self::CPT . '_sortable_columns', array( __CLASS__, 'sortable_columns' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'admin_sort' ) );

		add_shortcode( 'brautermine', array( __CLASS__, 'shortcode' ) );

		add_action( 'admin_post_brautermin_eintragen', array( __CLASS__, 'handle_eintragen' ) );
		add_action( 'admin_post_brautermin_austragen', array( __CLASS__, 'handle_austragen' ) );
		add_action( 'admin_post_nopriv_brautermin_eintragen', array( __CLASS__, 'handle_nopriv' ) );
		add_action( 'admin_post_nopriv_brautermin_austragen', array( __CLASS__, 'handle_nopriv' ) );
	}

	public static function activate() {
		self::create_table();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'brautermine_db_version' ) !== self::DB_VERSION ) {
			self::create_table();
		}
	}

	private static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE $table (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  termin_id bigint(20) unsigned NOT NULL,
  user_id bigint(20) unsigned NOT NULL,
  zeit_von time DEFAULT NULL,
  zeit_bis time DEFAULT NULL,
  kommentar varchar(255) NOT NULL DEFAULT '',
  erstellt datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY termin_user (termin_id,user_id)
) $charset;"
		);
		update_option( 'brautermine_db_version', self::DB_VERSION );
	}

	/** Wer darf sich eintragen? Standard: jeder angemeldete Nutzer. Per Filter änderbar. */
	private static function member_cap() {
		return apply_filters( 'brautermine_capability', 'read' );
	}

	public static function register_cpt() {
		register_post_type(
			self::CPT,
			array(
				'labels'          => array(
					'name'               => 'Brautermine',
					'singular_name'      => 'Brautermin',
					'menu_name'          => 'Brautermine',
					'add_new'            => 'Neuer Brautermin',
					'add_new_item'       => 'Neuen Brautermin anlegen',
					'edit_item'          => 'Brautermin bearbeiten',
					'new_item'           => 'Neuer Brautermin',
					'search_items'       => 'Brautermine durchsuchen',
					'not_found'          => 'Keine Brautermine gefunden',
					'not_found_in_trash' => 'Keine Brautermine im Papierkorb',
					'all_items'          => 'Alle Brautermine',
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'show_in_rest'    => false,
				'menu_position'   => 25,
				'menu_icon'       => 'dashicons-calendar-alt',
				'supports'        => array( 'title', 'editor', 'author' ),
				'capability_type' => 'post',
				'map_meta_cap'    => true,
			)
		);
	}

	/* ------------------------------------------------------------------
	 * Hilfsfunktionen
	 * ------------------------------------------------------------------ */

	private static function meta( $post_id ) {
		return array(
			'datum'  => (string) get_post_meta( $post_id, '_bt_datum', true ),
			'beginn' => (string) get_post_meta( $post_id, '_bt_beginn', true ),
			'ende'   => (string) get_post_meta( $post_id, '_bt_ende', true ),
			'ort'    => (string) get_post_meta( $post_id, '_bt_ort', true ),
			'max'    => (int) get_post_meta( $post_id, '_bt_max', true ),
		);
	}

	private static function clean_date( $s ) {
		$s = trim( (string) $s );
		$d = DateTime::createFromFormat( '!Y-m-d', $s );
		return ( $d && $d->format( 'Y-m-d' ) === $s ) ? $s : '';
	}

	private static function clean_time( $s ) {
		$s = substr( trim( (string) $s ), 0, 5 );
		return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $s ) ? $s : '';
	}

	private static function today() {
		return current_time( 'Y-m-d' );
	}

	private static function fmt_date( $ymd ) {
		if ( ! $ymd ) {
			return 'Datum offen';
		}
		$dt = DateTime::createFromFormat( '!Y-m-d', $ymd, wp_timezone() );
		return $dt ? wp_date( 'l, j. F Y', $dt->getTimestamp() ) : $ymd;
	}

	private static function fmt_range( $von, $bis, $leer = '' ) {
		$von = $von ? substr( $von, 0, 5 ) : '';
		$bis = $bis ? substr( $bis, 0, 5 ) : '';
		if ( $von && $bis ) {
			return $von . '–' . $bis . ' Uhr';
		}
		if ( $von ) {
			return 'ab ' . $von . ' Uhr';
		}
		if ( $bis ) {
			return 'bis ' . $bis . ' Uhr';
		}
		return $leer;
	}

	private static function get_signups( array $termin_ids ) {
		global $wpdb;
		$termin_ids = array_values( array_filter( array_map( 'absint', $termin_ids ) ) );
		if ( ! $termin_ids ) {
			return array();
		}
		$in    = implode( ',', $termin_ids );
		$table = self::table();
		// $in besteht ausschließlich aus absint()-Werten.
		$rows = $wpdb->get_results(
			"SELECT h.*, u.display_name, u.user_email
			   FROM $table h
			   LEFT JOIN {$wpdb->users} u ON u.ID = h.user_id
			  WHERE h.termin_id IN ($in)
			  ORDER BY h.termin_id, (h.zeit_von IS NULL), h.zeit_von, h.erstellt"
		);
		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[ (int) $r->termin_id ][] = $r;
		}
		return $out;
	}

	private static function count_signups( $termin_id ) {
		global $wpdb;
		$table = self::table();
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE termin_id = %d", $termin_id ) );
	}

	/* ------------------------------------------------------------------
	 * Backend: Metaboxen, Spalten, Sortierung
	 * ------------------------------------------------------------------ */

	public static function add_meta_boxes() {
		add_meta_box( 'bt_details', 'Termindetails', array( __CLASS__, 'render_details_box' ), self::CPT, 'side', 'high' );
		add_meta_box( 'bt_helfer', 'Eingetragene Helfer', array( __CLASS__, 'render_helfer_box' ), self::CPT, 'normal', 'default' );
	}

	public static function render_details_box( $post ) {
		$m = self::meta( $post->ID );
		wp_nonce_field( 'bt_save_meta', 'bt_meta_nonce' );
		?>
		<p>
			<label for="bt_datum"><strong>Brautag</strong></label><br>
			<input type="date" id="bt_datum" name="bt_datum" value="<?php echo esc_attr( $m['datum'] ); ?>" required style="width:100%">
		</p>
		<p>
			<strong>Uhrzeit</strong><br>
			<input type="time" name="bt_beginn" value="<?php echo esc_attr( $m['beginn'] ); ?>" aria-label="Beginn"> –
			<input type="time" name="bt_ende" value="<?php echo esc_attr( $m['ende'] ); ?>" aria-label="Ende">
		</p>
		<p>
			<label for="bt_ort"><strong>Ort</strong></label><br>
			<input type="text" id="bt_ort" name="bt_ort" value="<?php echo esc_attr( $m['ort'] ); ?>" style="width:100%" placeholder="z. B. Vereinsbrauerei">
		</p>
		<p>
			<label for="bt_max"><strong>Max. Helfer</strong></label><br>
			<input type="number" id="bt_max" name="bt_max" min="0" value="<?php echo esc_attr( $m['max'] ? $m['max'] : '' ); ?>" style="width:100%" placeholder="leer = unbegrenzt">
		</p>
		<p class="description">Bierstil, Rezept und Hinweise kommen ins große Textfeld – das sehen die Mitglieder beim Termin.</p>
		<?php
	}

	public static function save_meta( $post_id, $post ) {
		if ( ! isset( $_POST['bt_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bt_meta_nonce'] ) ), 'bt_save_meta' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_bt_datum', self::clean_date( wp_unslash( $_POST['bt_datum'] ?? '' ) ) );
		update_post_meta( $post_id, '_bt_beginn', self::clean_time( wp_unslash( $_POST['bt_beginn'] ?? '' ) ) );
		update_post_meta( $post_id, '_bt_ende', self::clean_time( wp_unslash( $_POST['bt_ende'] ?? '' ) ) );
		update_post_meta( $post_id, '_bt_ort', sanitize_text_field( wp_unslash( $_POST['bt_ort'] ?? '' ) ) );
		update_post_meta( $post_id, '_bt_max', absint( $_POST['bt_max'] ?? 0 ) );
	}

	public static function render_helfer_box( $post ) {
		$all  = self::get_signups( array( $post->ID ) );
		$list = $all[ $post->ID ] ?? array();
		if ( ! $list ) {
			echo '<p>Noch niemand eingetragen.</p>';
			return;
		}
		$zurueck = get_edit_post_link( $post->ID, 'raw' );
		echo '<table class="widefat striped"><thead><tr><th>Name</th><th>E-Mail</th><th>Zeit</th><th>Kommentar</th><th>Eingetragen am</th><th></th></tr></thead><tbody>';
		foreach ( $list as $h ) {
			$url = wp_nonce_url(
				add_query_arg(
					array(
						'action'  => 'brautermin_austragen',
						'eintrag' => (int) $h->id,
						'zurueck' => rawurlencode( $zurueck ),
					),
					admin_url( 'admin-post.php' )
				),
				'brautermin_austragen_' . $h->id
			);
			printf(
				'<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><a href="%s" onclick="return confirm(\'Eintrag wirklich entfernen?\');">Entfernen</a></td></tr>',
				esc_html( $h->display_name ? $h->display_name : 'Unbekannt (#' . (int) $h->user_id . ')' ),
				$h->user_email ? '<a href="mailto:' . esc_attr( $h->user_email ) . '">' . esc_html( $h->user_email ) . '</a>' : '–',
				esc_html( self::fmt_range( $h->zeit_von, $h->zeit_bis, 'ganze Zeit' ) ),
				esc_html( $h->kommentar ),
				esc_html( mysql2date( 'd.m.Y H:i', $h->erstellt ) ),
				esc_url( $url )
			);
		}
		echo '</tbody></table>';
		printf( '<p><strong>%d</strong> Helfer eingetragen.</p>', count( $list ) );
	}

	public static function admin_columns( $cols ) {
		$new = array();
		foreach ( $cols as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['bt_datum']  = 'Brautag';
				$new['bt_zeit']   = 'Uhrzeit';
				$new['bt_helfer'] = 'Helfer';
			}
		}
		unset( $new['date'] );
		return $new;
	}

	public static function admin_column_content( $col, $post_id ) {
		$m = self::meta( $post_id );
		switch ( $col ) {
			case 'bt_datum':
				echo esc_html( $m['datum'] ? self::fmt_date( $m['datum'] ) : '—' );
				break;
			case 'bt_zeit':
				echo esc_html( self::fmt_range( $m['beginn'], $m['ende'], '—' ) );
				break;
			case 'bt_helfer':
				$n = self::count_signups( $post_id );
				echo esc_html( $m['max'] ? $n . ' / ' . $m['max'] : (string) $n );
				break;
		}
	}

	public static function sortable_columns( $cols ) {
		$cols['bt_datum'] = 'bt_datum';
		return $cols;
	}

	public static function admin_sort( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() || self::CPT !== $q->get( 'post_type' ) ) {
			return;
		}
		$orderby = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : '';
		if ( '' === $orderby || 'bt_datum' === $orderby ) {
			$q->set( 'meta_key', '_bt_datum' );
			$q->set( 'orderby', 'meta_value' );
			if ( empty( $_GET['order'] ) ) {
				$q->set( 'order', 'DESC' );
			}
		}
	}

	public static function delete_signups( $post_id ) {
		if ( get_post_type( $post_id ) !== self::CPT ) {
			return;
		}
		global $wpdb;
		$wpdb->delete( self::table(), array( 'termin_id' => (int) $post_id ), array( '%d' ) );
	}

	/* ------------------------------------------------------------------
	 * Frontend: Shortcode [brautermine anzahl="20"]
	 * ------------------------------------------------------------------ */

	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'anzahl' => 20 ), $atts, 'brautermine' );

		ob_start();
		self::print_css();
		echo '<div class="bt-wrap">';

		if ( ! is_user_logged_in() || ! current_user_can( self::member_cap() ) ) {
			printf(
				'<p class="bt-hinweis">Die Brautermine sind nur für Mitglieder sichtbar. <a href="%s">Bitte anmelden</a>.</p></div>',
				esc_url( wp_login_url( get_permalink() ) )
			);
			return ob_get_clean();
		}

		self::print_notice();

		$posts = get_posts(
			array(
				'post_type'      => self::CPT,
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, (int) $atts['anzahl'] ),
				'meta_key'       => '_bt_datum',
				'orderby'        => 'meta_value',
				'order'          => 'ASC',
				'meta_query'     => array(
					array(
						'key'     => '_bt_datum',
						'value'   => self::today(),
						'compare' => '>=',
						'type'    => 'CHAR',
					),
				),
				'no_found_rows'  => true,
			)
		);

		if ( ! $posts ) {
			echo '<p class="bt-hinweis">Aktuell sind keine Brautermine geplant.</p></div>';
			return ob_get_clean();
		}

		$signups = self::get_signups( wp_list_pluck( $posts, 'ID' ) );
		$uid     = get_current_user_id();
		$zurueck = get_permalink();
		$action  = admin_url( 'admin-post.php' );

		foreach ( $posts as $p ) {
			$m    = self::meta( $p->ID );
			$list = $signups[ $p->ID ] ?? array();
			$mine = null;
			foreach ( $list as $h ) {
				if ( (int) $h->user_id === $uid ) {
					$mine = $h;
				}
			}
			$n    = count( $list );
			$voll = $m['max'] && $n >= $m['max'];
			$zeit = self::fmt_range( $m['beginn'], $m['ende'] );
			?>
			<article class="bt-termin" id="brautermin-<?php echo (int) $p->ID; ?>">
				<div class="bt-datum"><?php echo esc_html( self::fmt_date( $m['datum'] ) ); ?></div>
				<h3 class="bt-titel"><?php echo esc_html( get_the_title( $p ) ); ?></h3>
				<?php if ( $zeit || $m['ort'] ) : ?>
					<div class="bt-meta">
						<?php if ( $zeit ) : ?><span><strong>Uhrzeit:</strong> <?php echo esc_html( $zeit ); ?></span><?php endif; ?>
						<?php if ( $m['ort'] ) : ?><span><strong>Ort:</strong> <?php echo esc_html( $m['ort'] ); ?></span><?php endif; ?>
					</div>
				<?php endif; ?>
				<?php if ( trim( $p->post_content ) ) : ?>
					<div class="bt-beschreibung"><?php echo wpautop( wp_kses_post( $p->post_content ) ); ?></div>
				<?php endif; ?>

				<div class="bt-helfer">
					<div class="bt-helfer-kopf">Helfer: <strong><?php echo esc_html( $m['max'] ? $n . ' / ' . $m['max'] : (string) $n ); ?></strong></div>
					<?php if ( $list ) : ?>
						<ul>
							<?php foreach ( $list as $h ) : ?>
								<li class="<?php echo (int) $h->user_id === $uid ? 'bt-ich' : ''; ?>">
									<?php echo esc_html( $h->display_name ? $h->display_name : 'Unbekannt' ); ?>
									<?php if ( (int) $h->user_id === $uid ) : ?> (du)<?php endif; ?>
									<span class="bt-zeit"><?php echo esc_html( self::fmt_range( $h->zeit_von, $h->zeit_bis, 'ganze Zeit' ) ); ?></span>
									<?php if ( $h->kommentar ) : ?>
										<span class="bt-kommentar-text"><?php echo esc_html( $h->kommentar ); ?></span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						<p class="bt-leer">Noch niemand eingetragen.</p>
					<?php endif; ?>
				</div>

				<?php if ( $voll && ! $mine ) : ?>
					<p class="bt-voll">Alle Plätze sind belegt.</p>
				<?php else : ?>
					<form class="bt-form" method="post" action="<?php echo esc_url( $action ); ?>">
						<input type="hidden" name="action" value="brautermin_eintragen">
						<input type="hidden" name="termin_id" value="<?php echo (int) $p->ID; ?>">
						<input type="hidden" name="zurueck" value="<?php echo esc_url( $zurueck ); ?>">
						<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'brautermin_eintragen_' . $p->ID ) ); ?>">
						<label>von
							<input type="time" name="zeit_von" value="<?php echo esc_attr( $mine && $mine->zeit_von ? substr( $mine->zeit_von, 0, 5 ) : '' ); ?>">
						</label>
						<label>bis
							<input type="time" name="zeit_bis" value="<?php echo esc_attr( $mine && $mine->zeit_bis ? substr( $mine->zeit_bis, 0, 5 ) : '' ); ?>">
						</label>
						<label class="bt-feld-kommentar">Kommentar
							<input type="text" name="kommentar" maxlength="255" placeholder="optional" value="<?php echo esc_attr( $mine ? $mine->kommentar : '' ); ?>">
						</label>
						<button type="submit"><?php echo $mine ? 'Eintrag ändern' : 'Ich helfe mit'; ?></button>
						<p class="bt-tipp">Uhrzeit leer lassen, wenn du die ganze Zeit dabei bist.</p>
					</form>
					<?php if ( $mine ) : ?>
						<form class="bt-form-austragen" method="post" action="<?php echo esc_url( $action ); ?>" onsubmit="return confirm('Wirklich austragen?');">
							<input type="hidden" name="action" value="brautermin_austragen">
							<input type="hidden" name="eintrag" value="<?php echo (int) $mine->id; ?>">
							<input type="hidden" name="zurueck" value="<?php echo esc_url( $zurueck ); ?>">
							<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'brautermin_austragen_' . $mine->id ) ); ?>">
							<button type="submit" class="bt-link">Austragen</button>
						</form>
					<?php endif; ?>
				<?php endif; ?>
			</article>
			<?php
		}

		echo '</div>';
		return ob_get_clean();
	}

	private static function print_notice() {
		$msg   = isset( $_GET['bt_msg'] ) ? sanitize_key( wp_unslash( $_GET['bt_msg'] ) ) : '';
		$texte = array(
			'eingetragen' => array( 'ok', 'Danke! Du bist als Helfer eingetragen.' ),
			'geaendert'   => array( 'ok', 'Dein Eintrag wurde aktualisiert.' ),
			'ausgetragen' => array( 'ok', 'Du bist ausgetragen.' ),
			'voll'        => array( 'fehler', 'Leider sind schon alle Plätze belegt.' ),
			'zeit'        => array( 'fehler', 'Die Bis-Uhrzeit muss nach der Von-Uhrzeit liegen.' ),
			'vorbei'      => array( 'fehler', 'Dieser Termin liegt in der Vergangenheit.' ),
			'fehler'      => array( 'fehler', 'Das hat nicht geklappt. Bitte lade die Seite neu und versuche es noch einmal.' ),
		);
		if ( ! isset( $texte[ $msg ] ) ) {
			return;
		}
		printf(
			'<div class="bt-notice bt-notice-%s" role="status">%s</div>',
			esc_attr( $texte[ $msg ][0] ),
			esc_html( $texte[ $msg ][1] )
		);
	}

	private static function print_css() {
		if ( self::$css_printed ) {
			return;
		}
		self::$css_printed = true;
		?>
		<style>
		.bt-wrap{--bt-rand:rgba(127,127,127,.35);--bt-akzent:#b8860b;--bt-ok:#2e7d32;--bt-fehler:#c62828;display:grid;gap:1rem}
		.bt-termin{border:1px solid var(--bt-rand);border-left:4px solid var(--bt-akzent);border-radius:6px;padding:1rem 1.2rem}
		.bt-datum{font-size:.9em;font-weight:600;color:var(--bt-akzent)}
		.bt-titel{margin:.2rem 0 .4rem}
		.bt-meta{display:flex;flex-wrap:wrap;gap:.3rem 1.2rem;font-size:.9em}
		.bt-beschreibung{margin:.6rem 0}
		.bt-helfer{margin-top:.6rem}
		.bt-helfer ul{list-style:none;margin:.4rem 0;padding:0}
		.bt-helfer li{padding:.3rem 0;border-bottom:1px dashed var(--bt-rand)}
		.bt-helfer li:last-child{border-bottom:0}
		.bt-zeit{opacity:.75;font-size:.9em;margin-left:.4rem}
		.bt-kommentar-text{display:block;font-size:.85em;opacity:.75}
		.bt-ich{font-weight:600}
		.bt-leer{opacity:.7;margin:.3rem 0}
		.bt-form{display:flex;flex-wrap:wrap;gap:.5rem;align-items:flex-end;margin-top:.8rem}
		.bt-form label{display:flex;flex-direction:column;font-size:.85em}
		.bt-form .bt-feld-kommentar{flex:1 1 12rem}
		.bt-form input{padding:.35rem .4rem}
		.bt-tipp{font-size:.8em;opacity:.7;margin:0;width:100%}
		.bt-form-austragen{margin-top:.4rem}
		.bt-link{background:none;border:0;padding:0;color:inherit;text-decoration:underline;cursor:pointer;font-size:.85em}
		.bt-voll{font-weight:600;color:var(--bt-fehler)}
		.bt-notice{padding:.6rem .9rem;border-radius:4px;border-left:4px solid}
		.bt-notice-ok{border-color:var(--bt-ok);background:rgba(46,125,50,.08)}
		.bt-notice-fehler{border-color:var(--bt-fehler);background:rgba(198,40,40,.08)}
		</style>
		<?php
	}

	/* ------------------------------------------------------------------
	 * Formular-Verarbeitung
	 * ------------------------------------------------------------------ */

	public static function handle_nopriv() {
		$ref = wp_get_referer();
		wp_safe_redirect( wp_login_url( $ref ? $ref : home_url( '/' ) ) );
		exit;
	}

	private static function back( $msg, $termin_id = 0 ) {
		$url = isset( $_REQUEST['zurueck'] ) ? esc_url_raw( wp_unslash( $_REQUEST['zurueck'] ) ) : '';
		$url = wp_validate_redirect( $url, '' );
		if ( ! $url ) {
			$ref = wp_get_referer();
			$url = $ref ? $ref : home_url( '/' );
		}
		$url = preg_replace( '/#.*$/', '', $url );
		$url = add_query_arg( 'bt_msg', $msg, remove_query_arg( 'bt_msg', $url ) );
		if ( $termin_id ) {
			$url .= '#brautermin-' . (int) $termin_id;
		}
		wp_safe_redirect( $url );
		exit;
	}

	public static function handle_eintragen() {
		$termin_id = absint( $_POST['termin_id'] ?? 0 );
		$nonce     = sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ?? '' ) );
		if ( ! wp_verify_nonce( $nonce, 'brautermin_eintragen_' . $termin_id ) || ! current_user_can( self::member_cap() ) ) {
			self::back( 'fehler', $termin_id );
		}

		$post = get_post( $termin_id );
		if ( ! $post || self::CPT !== $post->post_type || 'publish' !== $post->post_status ) {
			self::back( 'fehler', $termin_id );
		}
		$m = self::meta( $termin_id );
		if ( ! $m['datum'] || $m['datum'] < self::today() ) {
			self::back( 'vorbei', $termin_id );
		}

		$von = self::clean_time( wp_unslash( $_POST['zeit_von'] ?? '' ) );
		$bis = self::clean_time( wp_unslash( $_POST['zeit_bis'] ?? '' ) );
		if ( $von && $bis && $bis <= $von ) {
			self::back( 'zeit', $termin_id );
		}
		$kommentar = mb_substr( sanitize_text_field( wp_unslash( $_POST['kommentar'] ?? '' ) ), 0, 255 );

		global $wpdb;
		$table = self::table();
		$uid   = get_current_user_id();
		$data  = array(
			'zeit_von'  => $von ? $von . ':00' : null,
			'zeit_bis'  => $bis ? $bis . ':00' : null,
			'kommentar' => $kommentar,
		);

		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE termin_id = %d AND user_id = %d", $termin_id, $uid ) );
		if ( $id ) {
			$wpdb->update( $table, $data, array( 'id' => $id ) );
			self::back( 'geaendert', $termin_id );
		}

		if ( $m['max'] && self::count_signups( $termin_id ) >= $m['max'] ) {
			self::back( 'voll', $termin_id );
		}

		$ok = $wpdb->insert(
			$table,
			$data + array(
				'termin_id' => $termin_id,
				'user_id'   => $uid,
				'erstellt'  => current_time( 'mysql' ),
			)
		);
		if ( $ok ) {
			self::notify_author( $post, $uid, $data );
			do_action( 'brautermine_eingetragen', $termin_id, $uid );
		}
		self::back( $ok ? 'eingetragen' : 'fehler', $termin_id );
	}

	public static function handle_austragen() {
		$id    = absint( $_REQUEST['eintrag'] ?? 0 );
		$nonce = sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ?? '' ) );
		if ( ! wp_verify_nonce( $nonce, 'brautermin_austragen_' . $id ) ) {
			self::back( 'fehler' );
		}

		global $wpdb;
		$table = self::table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
		if ( ! $row ) {
			self::back( 'fehler' );
		}
		$termin_id = (int) $row->termin_id;
		$eigener   = (int) $row->user_id === get_current_user_id();
		if ( ! $eigener && ! current_user_can( 'edit_post', $termin_id ) ) {
			self::back( 'fehler', $termin_id );
		}
		$wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
		do_action( 'brautermine_ausgetragen', $termin_id, (int) $row->user_id );
		self::back( 'ausgetragen', $termin_id );
	}

	/** Mail an den Ersteller des Termins bei neuer Eintragung. Abschaltbar per Filter. */
	private static function notify_author( $post, $uid, $data ) {
		if ( ! apply_filters( 'brautermine_mail_an_autor', true, $post ) ) {
			return;
		}
		$author = get_userdata( (int) $post->post_author );
		$helfer = get_userdata( $uid );
		if ( ! $author || ! $helfer || (int) $author->ID === $uid || ! $author->user_email ) {
			return;
		}
		$m       = self::meta( $post->ID );
		$betreff = sprintf(
			'[%s] Neuer Helfer für „%s“',
			wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			$post->post_title
		);
		$text = sprintf(
			"%s hat sich für den Brautermin „%s“ am %s eingetragen.\n\nZeit: %s\nKommentar: %s\n\nÜbersicht: %s\n",
			$helfer->display_name,
			$post->post_title,
			self::fmt_date( $m['datum'] ),
			self::fmt_range( $data['zeit_von'], $data['zeit_bis'], 'ganze Zeit' ),
			$data['kommentar'] ? $data['kommentar'] : '–',
			get_edit_post_link( $post->ID, 'raw' )
		);
		wp_mail( $author->user_email, $betreff, $text );
	}
}

register_activation_hook( __FILE__, array( 'Brautermine', 'activate' ) );
Brautermine::init();
