<?php
/**
 * Wird nur beim LÖSCHEN des Plugins im Backend ausgeführt (nicht beim Deaktivieren).
 * Entfernt Helfer-Tabelle, Einstellungen und alle Brautermine.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}brautermin_helfer" );
delete_option( 'brautermine_db_version' );

$ids = get_posts(
	array(
		'post_type'   => 'brautermin',
		'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future', 'trash' ),
		'numberposts' => -1,
		'fields'      => 'ids',
	)
);
foreach ( $ids as $id ) {
	wp_delete_post( $id, true );
}
